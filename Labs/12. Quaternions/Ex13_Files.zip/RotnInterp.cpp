//  ========================================================================
//  COSC422: Advanced Computer Graphics;  University of Canterbury.
//
//  FILE NAME: RotnInterp.cpp
//
//	See  Ex13_Quaternions.pdf for details.
//  Shader files:  Shader.h,  RotnInterp.vert, RotnInterp.frag
//  The program displays the motion of a teapot computed using a linear interpolation between
//  two orientations in 3D space.
//  Press space bar to repeat the interpolation sequence
//  ========================================================================
#include <fstream>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "Shader.h"
using namespace std;

GLuint matrixLoc1, matrixLoc2, matrixLoc3, lgtLoc;
float t = 0;       //Interpolation parameter
ifstream ifile;
unsigned int vaoID, vboID[3];
int numTri;
float CDR = 3.14159265/180.0;   //Conversion from degrees to radians (required in GLM functions)

void initialise()
{
	int numVert, numNorm;
	GLuint program = createShaderProg("RotnInterp.vert", "RotnInterp.frag");
	matrixLoc1 = glGetUniformLocation(program, "mvMatrix");
	matrixLoc2 = glGetUniformLocation(program, "mvpMatrix");
	matrixLoc3 = glGetUniformLocation(program, "norMatrix");
	lgtLoc = glGetUniformLocation(program, "lightPos");

	//Read teapot data
	ifile.open("Teapot.dat", ios::in);

	ifile >> numVert >> numNorm >> numTri;	//Number of vertices, number of normals, number of triangles
											//Note:  Number of vertices must be equal to number of normals
    float * vert = new float[ numVert * 3 ];
    float * norm = new float[ numNorm * 3 ];
    unsigned int * elem = new unsigned int[numTri * 3];

	for(int i = 0;  i < numVert; i++)
		ifile >> vert[3*i] >> vert[3*i+1] >> vert[3*i+2];

	for(int i = 0;  i < numNorm; i++)
		ifile >> norm[3*i] >> norm[3*i+1] >> norm[3*i+2];

	for(int i = 0;  i < numTri; i++)
		ifile >> elem[3*i] >> elem[3*i+1] >> elem[3*i+2];

	//Generate buffers
    glGenVertexArrays( 1, &vaoID);
    glBindVertexArray(vaoID);

    glGenBuffers(3, vboID);

    glBindBuffer(GL_ARRAY_BUFFER, vboID[0]);
    glBufferData(GL_ARRAY_BUFFER, (3 * numVert) * sizeof(float), vert, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(0);  // Vertex position

    glBindBuffer(GL_ARRAY_BUFFER, vboID[1]);
    glBufferData(GL_ARRAY_BUFFER, (3 * numNorm) * sizeof(float), norm, GL_STATIC_DRAW);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glEnableVertexAttribArray(1);  // Vertex normal

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vboID[2]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, (3 * numTri) * sizeof(unsigned int), elem, GL_STATIC_DRAW);

    delete [] vert;
    delete [] norm;
    delete [] elem;
    glBindVertexArray(0);

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glEnable(GL_DEPTH_TEST);
}


void update(int value)
{
	t += 0.01;
	value++;
	if (value < 100) glutTimerFunc(50.0, update, value);
	glutPostRedisplay();
}


void keyboard(unsigned char key, int x, int y)
{
	if (key == ' ')   //Repeat animation
	{
		t = 0;      //Reset interpolation parameter
		glutTimerFunc(50, update, 0);
		glutPostRedisplay();
	}
}

void display()
{
	glm::vec4 light = glm::vec4(20.0, 20.0, 50.0, 1.0);
	glm::mat4 proj = glm::perspective(30.0f*CDR, 1.0f, 10.0f, 1000.0f);  //perspective projection matrix
	glm::mat4 view = glm::lookAt(glm::vec3(0.0, 0.0, 50.0), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0)); //view matrix

	//===== Configuration 1 ======
	float angle1 = 120.0f;
	glm::vec3 axis1 = glm::vec3(-0.8165, 0.40825, -0.40825);
	glm::vec3 trans1 = glm::vec3(-2.0, 8.0, 0.0);
	
	//===== Configuration 2 ======
	float angle2 = -50.0f;
	glm::vec3 axis2 = glm::vec3(0.440225, -0.88045, 0.17609);
	glm::vec3 trans2 = glm::vec3(3.0, -5.0, 0.0);

	//===== Interpolate between the two configurations ======
	glm::vec3 trans = glm::mix(trans1, trans2, t);    //Translation interpolation
	float angle = glm::mix(angle1, angle2, t);        //Rotation angle interpolation
	glm::vec3 axis = glm::mix(axis1, axis2, t);		  //Rotation axis interpolation

	//===== Now form the transformation matrices ======
	glm::mat4 idMatrix = glm::mat4(1.0);							//Identity
	glm::mat4 transln = glm::translate(idMatrix, trans);			//Translation matrix
	glm::mat4 rotation = glm::rotate(idMatrix, angle*CDR, axis);	//Rotation matrix
	glm::mat4 trMatrix = transln * rotation;						//TR matrix (The 3D transformation matrix)

	glm::mat4 mvMatrix = view * trMatrix;				//Model-view matrix
	glm::mat4 mvpMatrix = proj * mvMatrix;				//Model-view-projection matrix
	glm::vec4 lightEye = view * light;						//Light position in eye coordinates
	glm::mat4 norMatrix = glm::inverse(mvMatrix);  //Inverse of model-view matrix for normal transformation
	glUniformMatrix4fv(matrixLoc1, 1, GL_FALSE, &mvMatrix[0][0]);
	glUniformMatrix4fv(matrixLoc2, 1, GL_FALSE, &mvpMatrix[0][0]);
	glUniformMatrix4fv(matrixLoc3, 1, GL_TRUE, &norMatrix[0][0]);  //Use transpose matrix here
	glUniform4fv(lgtLoc, 1, &lightEye[0]);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glBindVertexArray(vaoID);
    glDrawElements(GL_TRIANGLES, 3*numTri, GL_UNSIGNED_INT, NULL);

	glFlush();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Rotation Interpolation");
	glutInitContextVersion (4, 2);
	glutInitContextProfile ( GLUT_CORE_PROFILE );

	if(glewInit())
	{
		cerr << "Unable to initialize GLEW  ...exiting" << endl;
		exit(EXIT_FAILURE);
	}

	initialise();
	glutDisplayFunc(display);
	glutTimerFunc(50, update, 0); 
	glutKeyboardFunc(keyboard);
	glutMainLoop();
}

